import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-locale',
  templateUrl: './select-locale.component.html',
  styleUrls: ['./select-locale.component.scss']
})
export class SelectLocaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
