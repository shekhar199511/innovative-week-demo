export const environment = {
  production: true,
  contentful: {
    spaceId: 'kq4h4rlsuev2',
    token: 'O4OhcP1nhTbQlqQOhYl77JW8xIE03TeQV6Tz0tpgKzs'
  }
};
